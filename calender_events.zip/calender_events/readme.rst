You can go through the tutorial https://www.roytuts.com/bootstrap-calendar-events-demo-using-python-flask-mysql/
